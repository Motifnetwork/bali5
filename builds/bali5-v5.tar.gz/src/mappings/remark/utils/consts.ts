const RMRK_PREFIXES = ['rmrk', 'RMRK']

export default {
    RMRK_PREFIXES,
}
