export enum StakingRole {
    Validator = "Validator",
    Nominator = "Nominator",
    Idle = "Idle",
}
