export enum CrowdloanStatus {
    Started = "Started",
    Ended = "Ended",
    Dissolved = "Dissolved",
}
