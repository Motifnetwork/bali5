export enum PayeeType {
    Staked = "Staked",
    Stash = "Stash",
    Controller = "Controller",
    Account = "Account",
    None = "None",
}
