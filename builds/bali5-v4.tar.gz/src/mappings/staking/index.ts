import * as events from './events'
import * as extrinsics from './calls'
import * as hooks from './hooks'

export default {
    events,
    extrinsics,
    hooks,
}
