export * from './slashed'
