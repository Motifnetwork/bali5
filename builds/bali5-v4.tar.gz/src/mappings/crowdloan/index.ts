import * as events from './events'
import * as extrinsics from './calls'

export default {
    events,
    extrinsics,
}
