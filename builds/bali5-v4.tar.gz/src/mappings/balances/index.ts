import * as extrinsics from './calls'
import * as events from './events'

export default {
    extrinsics,
    events,
}
